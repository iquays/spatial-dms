Leaflet measure control
=======================

Adds a button below the map's zoom controls that allows you to activate an interactive mode to measure distances on the map.

More info coming soon...

For a demo see [here](http://jtreml.github.com/leaflet.measure/example.html).