## Contributing

Thank you for considering contributing to leaflet.pm.

Follow these steps to get up and running:

1. clone the repository
2. run `npm install` to install all dependencies.
3. run `npm run dev` to start watching the files.
4. open `demo/index.html` in your browser to see the changes to you inside the `src` folder.
